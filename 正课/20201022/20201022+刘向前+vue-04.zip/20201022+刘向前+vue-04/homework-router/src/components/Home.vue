<!--
 * @Descripttion:
 * @version:
 * @Author: 刘向前
 * @Date: 2020-10-24 09:55:17
 * @LastEditors: 刘向前
 * @LastEditTime: 2020-10-24 09:56:14
-->
<template>
  <div>
    this is home page
  </div>
</template>

<script>
  export default {
    name: 'Hone'
  }
</script>

<style lang="scss" scoped>

</style>
