/*
 * @Author       : your name
 * @Date         : 2020-11-08 16:12:21
 * @LastEditTime : 2020-11-08 16:17:04
 * @LastEditors  : Please set LastEditors
 * @Description  : In User Settings Edit
 * @FilePath     : \re-study-web\正课\20201107\20201107+刘向前+react01\homework\src\components\FriendList\data.js
 */
const data = [
  {
    title: '家人',
    content: ['爸爸', '妈妈']
  },
  {
    title: '朋友',
    content: ['张三', '李四', '王五']
  },
  {
    title: '客户',
    content: ['阿里', '腾讯', '头条']
  }
]
export default data
