/*
 * @Author       : your name
 * @Date         : 2020-11-08 16:00:23
 * @LastEditTime : 2020-11-08 17:03:40
 * @LastEditors  : Please set LastEditors
 * @Description  : In User Settings Edit
 * @FilePath     : \re-study-web\正课\20201107\20201107+刘向前+react01\homework\src\index.js
 */
import React from 'react'
import ReactDOM from 'react-dom'
import FriendList from './components/FriendList/index'

ReactDOM.render(
  <div>
    <FriendList />
  </div>,
  document.getElementById('root')
)
