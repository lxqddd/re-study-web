/*
 * @Author       : your name
 * @Date         : 2020-11-11 22:20:52
 * @LastEditTime : 2020-11-11 23:40:06
 * @LastEditors  : Please set LastEditors
 * @Description  : In User Settings Edit
 * @FilePath     : \re-study-web\正课\20201110\20201110+刘向前+react02\homework\src\index.js
 */
import React from 'react'
import ReactDOM from 'react-dom'
import MessageBoard from './views/MessageBoard/index'

// 海哥真帅 ========================
ReactDOM.render(
  <div>
    <MessageBoard />
  </div>,
  document.getElementById('root')
)
